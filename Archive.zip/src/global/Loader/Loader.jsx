import React from 'react'
import './loader.css'
export default function () {return <div class="dot-flashing"></div>}