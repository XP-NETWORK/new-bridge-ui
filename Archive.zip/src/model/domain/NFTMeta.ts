export type NFTMeta = {
    id: string,
    hash: string;
    link: string;
    name: string;
    data: string;
}